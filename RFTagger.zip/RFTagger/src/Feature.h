
/*******************************************************************/
/*                                                                 */
/*     File: Feature.h                                             */
/*   Author: Helmut Schmid                                         */
/*  Purpose:                                                       */
/*  Created: Mon Jul  9 15:13:01 2007                              */
/* Modified: Wed Jul 18 11:22:27 2007 (schmid)                     */
/*                                                                 */
/*******************************************************************/

#include <set>
using std::set;

typedef unsigned short Feature;
typedef set<Feature> FeatureSet;

